"use client"

// DM Assets — the slide-over behind the gear icon.
//
// Five tabs over one idea: everything the DM can swap out without redeploying.
// NPCs keep their own tab because their identity is by NAME (every row sharing a
// name gets the same art) and they route through /api/npc-face and
// /api/npc-video. The other four are row-keyed and share /api/asset-media.
//
// EVERY SLOT TAKES A VIDEO. Previously only NPC faces could hold a loop —
// image-uploader.tsx hardcoded accept="image/*" and the assets panel rendered
// everything through <img>, so a scene background could only ever be a still.
// Now a scene, a fog overlay, an item icon or a library asset can each be an MP4,
// and MediaSlot picks <video> or <img> from the URL.
//
// Clearing removes the DATABASE REFERENCE ONLY, never the file — blob objects are
// shared between rows and deletion cannot be undone. Re-upload overwrites at the
// same deterministic path.
//
// DM-only: the parent renders this for a DM browser, and both endpoints re-check
// DM_ACCESS_CODE server-side.

import { useEffect, useState } from "react"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import { NpcAssetsTab } from "./npc-assets-panel"
import { MediaTab, type MediaTabConfig } from "./dm-assets/media-tab"

type TabId = "npcs" | "scenes" | "overlays" | "items" | "library"

const SCENES: MediaTabConfig = {
  table: "environments",
  select: "id, name, time_of_day, background_image_url",
  labelColumn: "name",
  subtitleColumn: "time_of_day",
  orderBy: "name",
  slots: [{ target: "environment.background", column: "background_image_url", label: "Background" }],
  emptyMessage: "No environments recorded yet.",
}

const OVERLAYS: MediaTabConfig = {
  table: "environments",
  select: "id, name, time_of_day, fog_overlay_url",
  labelColumn: "name",
  subtitleColumn: "time_of_day",
  orderBy: "name",
  slots: [{ target: "environment.fog", column: "fog_overlay_url", label: "Fog overlay" }],
  emptyMessage: "No environments recorded yet.",
}

const ITEMS: MediaTabConfig = {
  table: "items",
  select: "id, name, slug, item_type, icon_url",
  labelColumn: "name",
  subtitleColumn: "item_type",
  orderBy: "name",
  slots: [{ target: "item.icon", column: "icon_url", label: "Icon" }],
  emptyMessage: "No items in the catalogue yet.",
}

const LIBRARY: MediaTabConfig = {
  table: "dashboard_assets",
  select: "id, name, asset_type, file_url, thumbnail_url",
  labelColumn: "name",
  subtitleColumn: "asset_type",
  orderBy: "name",
  slots: [
    { target: "asset.file", column: "file_url", label: "File" },
    { target: "asset.thumbnail", column: "thumbnail_url", label: "Thumbnail" },
  ],
  emptyMessage: "No dashboard assets recorded yet.",
}

const TABS: Array<{ id: TabId; label: string; blurb: string }> = [
  { id: "npcs", label: "NPCs", blurb: "Canon face, idle and talking loops, and the ElevenLabs voice. Applies to every row sharing a name." },
  { id: "scenes", label: "Scenes", blurb: "Environment backgrounds. A looping MP4 works here — an animated cavern, drifting water." },
  { id: "overlays", label: "Overlays", blurb: "Fog and ambient layers drawn over the scene." },
  { id: "items", label: "Items", blurb: "Catalogue icons. Set the Rags roundel here." },
  { id: "library", label: "Library", blurb: "Everything else in dashboard_assets." },
]

export function DmAssetsPanel({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<TabId>("npcs")

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [onClose])

  const active = TABS.find((t) => t.id === tab)

  return (
    <div
      className="fixed inset-0 z-[300] flex justify-end bg-black/70 backdrop-blur-sm"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-label="DM Assets"
        className="flex h-full w-full max-w-3xl flex-col border-l border-[#6b5123] bg-[radial-gradient(circle_at_top,#1d1509,#0a0806_65%)] shadow-[-25px_0_80px_#000]"
      >
        <header className="shrink-0 border-b border-[#3d3428] px-5 py-3">
          <div className="flex items-center gap-3">
            <h2 className="font-serif text-lg tracking-wide text-[#c4a777]">DM Assets</h2>
            <button
              onClick={onClose}
              aria-label="Close DM Assets"
              className="ml-auto rounded border border-[#4b3a19] p-1.5 text-[#c6a060] hover:border-[#c9a868] hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <nav className="mt-3 flex flex-wrap gap-1" role="tablist">
            {TABS.map((t) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={tab === t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "rounded-sm border px-3 py-1 text-[11px] uppercase tracking-[0.14em] transition-colors",
                  tab === t.id
                    ? "border-[#c9a868] bg-[#c4a777]/12 text-[#f0dcae]"
                    : "border-[#3d3428] text-stone-500 hover:border-[#c4a777]/60 hover:text-[#d9c79c]",
                )}
              >
                {t.label}
              </button>
            ))}
          </nav>

          {active && <p className="mt-2 text-[11px] leading-snug text-stone-500">{active.blurb}</p>}
          <p className="mt-1 text-[10px] text-stone-600">
            Clearing removes the reference; the file stays in storage and re-uploading restores it.
          </p>
        </header>

        <div className="flex min-h-0 flex-1 flex-col">
          {tab === "npcs" && <NpcAssetsTab />}
          {tab === "scenes" && <MediaTab key="scenes" config={SCENES} />}
          {tab === "overlays" && <MediaTab key="overlays" config={OVERLAYS} />}
          {tab === "items" && <MediaTab key="items" config={ITEMS} />}
          {tab === "library" && <MediaTab key="library" config={LIBRARY} />}
        </div>
      </section>
    </div>
  )
}
